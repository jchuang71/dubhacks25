using UnityEngine;

// class for storing all base data related to a tile
// do not store scoped variables here, only data that is needed to be saved and used between scripts
public class TileData 
{

}
